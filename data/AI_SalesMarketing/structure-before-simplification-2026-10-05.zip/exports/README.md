# 열람·배포용 산출물

현재 [영업·마케팅 HTML](AI_SalesMarketing/ax_cases_atlas.html)은 제공받은 파일의 내용 그대로 보존한 열람용 사본이다. 새 위키에서 재생성한 결과는 아니다.

향후 src/exporters가 기준 JSON과 근거 문서를 바탕으로 주제별 산출물을 생성한다. exports의 결과를 고치는 대신 기준 입력을 수정한다.
