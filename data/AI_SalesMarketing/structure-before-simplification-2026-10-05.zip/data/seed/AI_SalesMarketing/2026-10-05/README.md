# 영업·마케팅 Seed 원본 — 2026-10-05

세 파일을 루트에서 이 위치로 이동했다. 내용은 변경하지 않았으며 [manifest.json](manifest.json)의 SHA-256으로 확인할 수 있다.

- [원본 JSON](cases_updated_all.json)
- [원본 조사 보고서](cases_update_report.md)
- [원본 HTML](ax_cases_atlas.html)

이 묶음은 보존용이다. 새 사례 편집은 [편집용 JSON](../../../processed/AI_SalesMarketing/cases.json), HTML 열람은 [exports](../../../../exports/AI_SalesMarketing/ax_cases_atlas.html)을 사용한다. 원본 보고서 안의 다른 파일명은 당시 기록이며, 해당 실행 코드·감사 파일이 모두 제공된 것은 아니다.
