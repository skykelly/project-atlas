# 1-1 신규 고객 획득

[영업·마케팅 위키](../README.md) · [전체 카테고리](README.md)

상태: 카테고리 정의·seed 목록 작성 / 기준일: 2026-10-05 / seed 레코드: 34건

## 범위

신규 고객을 발견·유입시키고 적격 리드를 확보하는 AI 활용을 다룬다.

포함 영역: AI 검색·GEO, 광고 타기팅, 잠재 고객 발굴, 리드 선별, 체험형 유입.

유입 이후 구매 완료는 1-2, 광고·콘텐츠 제작 원가는 2-1에서 함께 살핀다.

## 핵심 연구 질문

- AI가 기존에 접근하지 못한 고객을 찾는가?
- 유입량 증가가 적격 리드·신규 구매로 이어지는가?
- 타기팅·콘텐츠·매체 변화의 영향을 구분할 수 있는가?

## 앞으로 작성할 하위 연구 문서

다음은 작성 범위의 정의이며, 개별 심층 문서는 아직 생성하지 않았다. 사례별 문서는 공통 cases 폴더에 한 번만 만들고 이 문서에서 연결한다.

1. **AI 검색·GEO와 고객 발견**
2. **광고 타기팅과 신규 고객 확보**
3. **리드 발굴·선별의 업무 변화**

## 성과를 읽는 기준

신규 고객 수·비중, 적격 리드, CAC, 유입당 전환. 노출·클릭·방문 수를 신규 매출로 해석하지 않는다.

## 현재 seed 목록

아래 기업명·제목은 제공된 JSON의 목록을 옮긴 것이다. 원문을 이번에 재검증하지 않았으며, 분류 적합성·성과의 정확성이 확정된 목록은 아니다. 기존 ID와 분류를 유지했다. [기준 JSON](../../data/processed/AI_SalesMarketing/cases.json) · [기존 HTML 열람](../../exports/AI_SalesMarketing/ax_cases_atlas.html)

| 기존 ID | 기업 | seed 제목 | 출처 |
| --- | --- | --- | --- |
| `SEP-001` | Sephora | AI 버추얼 아티스트 — 체험형 고객 획득 | [원문](https://www.pragmatic.digital/blog/ai-marketing-case-study-successful-campaigns) |
| `LOR-001` | 로레알 | Google AI Max 검색 마케팅 | [원문](https://business.google.com/us/think/ai-excellence/loreal-ai-max-search-marketing-strategy/) |
| `UNI-001` | 유니레버 | AI 타겟팅·소비자 인사이트 | [원문](https://infotechlead.com/cio/unilever-drives-digital-ai-and-e-commerce-growth-with-2x-faster-marketing-and-e800-mn-cost-savings-94832) |
| `CCO-001` | 코카콜라 | Project Fizzion — AI 캠페인 자동화 | [원문](https://www.coca-colacompany.com/media-center/the-coca-cola-company-introduces-fizzion) |
| `DG-20260506-9c71e4` | Dollar General | 온사이트·오프사이트 광고 통합 | [원문](https://www.marketingdive.com/news/dollar-general-bridges-onsite-offsite-retail-media-with-new-solution/819190/) |
| `OMC-20260506-6d0cab` | Omnicom | 신규 고객 확보 사례 | [원문](https://www.marketingdive.com/news/omnicom-credits-q1-wins-to-core-operations-reaffirms-ongoing-cost-cuts/819157/) |
| `ABK-20260506-6b8d8f` | Airbank | Airbank의 글로벌 확장 | [원문](https://www.klarna.com/international/press/airbank-chooses-klarna-kosmas-open-banking-platform-for-international-expansion/) |
| `AMZ-20260508-ca22d7` | Amazon | Amazon과 LinkedIn의 협업 | [원문](https://www.marketingdive.com/news/amazon-linkedin-help-advertisers-reach-professionals-via-ctv-ads/819372/) |
| `TDK-20260509-f9d9ab` | Trade Desk | AI 챗봇 광고 기회 | [원문](https://www.marketingdive.com/news/where-trade-desk-sees-advertising-opportunity-following-bruising-q1/819692/) |
| `OAI-20260512-a516dd` | OpenAI | OpenAI 광고 플랫폼 확장 | [원문](https://www.marketingdive.com/news/openai-solidifies-ad-platform-ambitions-with-chatgpt-ads-manager/819801/) |
| `ZG-20260512-423eae` | Zeta Global | AI 기반 고객 획득 향상 | [원문](https://www.marketingdive.com/spons/the-gap-between-modern-and-legacy-esps-is-widening/819253/) |
| `FL-20260513-3a26a7` | Foot Locker | 농구 브랜드 플랫폼 론칭 | [원문](https://www.marketingdive.com/news/foot-locker-debuts-year-round-basketball-brand-platform-under-new-cmo/819693/) |
| `GGL-20260521-10e793` | Google | AI 광고 도구로 신규 고객 확보 | [원문](https://www.marketingdive.com/news/google-upgrades-ai-search-ads-what-marketers-need-to-know/820663/) |
| `ALY-20260521-0623f3` | Ally | 밀레니얼·Z세대 겨냥한 캠페인 | [원문](https://www.marketingdive.com/news/ally-billboard-marketing-gen-z-millennials-digital-banking-branches/820727/) |
| `HMK-20260527-cb380e` | Homemakers | AI 기반 웹사이트 구축 | [원문](https://www.salesforce.com/blog/storefront-next/) |
| `YT-20260529-d32940` | YouTube | AI 라벨 강화 | [원문](https://www.marketingdive.com/news/sociable-youtube-introduces-more-prominent-ai-labels/821378/) |
| `CP-20260603-9a794c` | ClassPass | 파트너 성장 위한 투자 | [원문](https://www.marketingdive.com/news/why-classpass-invested-50m-in-marketing-to-supercharge-partner-growth/821612/) |
| `AAP-20260603-aef745` | Advance Auto Parts | 신속한 부품 제공 | [원문](https://www.supplychaindive.com/news/advance-auto-parts-nears-finish-line-on-distribution-center-consolidation-s/821377/) |
| `GRT-20260610-e4b071` | Gartner | AI로 고객 획득 가속화 | [원문](https://www.marketingdive.com/news/customer-acquisition-media-spend-accelerates-amid-rush-to-ai-gartner/822274/) |
| `SIM-20260611-5c6c83` | Siemens | Siemens의 AI 리드 자격화 | [원문](https://www.salesforce.com/blog/autonomous-lead-qualification-agentforce/) |
| `CGB-20260612-72e89f` | Conagra Brands | 실시간 타겟팅 강화 | [원문](https://www.marketingdive.com/news/how-gstv-steps-up-audience-targeting-with-stagwells-agentic-system/822396/) |
| `EA-20260616-efbe72` | Electronic Arts | EA 광고 플랫폼 런칭 | [원문](https://www.marketingdive.com/news/ea-rolls-out-advertising-platform-with-enhanced-offerings-for-brands/822833/) |
| `CCH-20260617-9c714b` | Coach | Gen Z와의 협업 마케팅 | [원문](https://www.marketingdive.com/news/coach-unites-celebrities-gen-z-storytelling-under-new-brand-platform/822999/) |
| `RDT-20260619-41fb4c` | Reddit | 레딧 사용자 구매 행동 | [원문](https://www.marketingdive.com/news/sociable-reddit-study-highlights-user-purchase-behavior/823273/) |
| `WMT-20260630-09bbb2` | Walmart | Walmart Vibe.co 인수 | [원문](https://www.marketingdive.com/news/what-walmarts-vibeco-deal-means-for-ctv-retail-media-convergence/823941/) |
| `RDT-20260703-a3708b` | Reddit | 레딧, 사람의 힘 강조 캠페인 | [원문](https://www.marketingdive.com/news/sociable-reddit-launches-people-are-the-best-campaign/824366/) |
| `MHH-20260703-88573c` | Mike's Hot Honey | 축구 캠페인으로 고객 유입 | [원문](https://www.marketingdive.com/news/mikes-hot-honey-spurs-experimentation-with-soccer-infused-campaign/824276/) |
| `YET-20260719-192a4c` | Yeti | Yeti의 새로운 브랜드 플랫폼 | [원문](https://www.marketingdive.com/news/campaign-trail-yeti-spells-out-consumer-passions-with-four-letter-words/825390/) |
| `WD40-20261001-001` | WD-40 Company | AI 영상 광고 — 신규 브랜드 구매 고객 확보 | [원문](https://advertising.amazon.com/en-gb/library/case-studies/wd-40-and-bizon) |
| `LEN-20261001-001` | Lenovo | AI Max — 비브랜드 검색 수요 발굴 | [원문](https://business.google.com/uk/think/ai-excellence/lenovo-emea-ai-max-search-strategy/) |
| `DRB-20261001-001` | DerbySoft / 일본 호텔 체인 | AI Max — 기존 키워드 밖의 호텔 예약 수요 발굴 | [원문](https://www.derbysoft.com/resources/blog/case-study-scaling-success-with-ai-max-for-search/) |
| `UGI-20261001-001` | Umberto Giannini | AI 컬 진단 퀴즈 — 첫 구매 고객 확보 | [원문](https://www.tangent.ai/umberto-giannini-case-study) |
| `SEEN-20261001-001` | SEEN | AI 민감 두피 상담 — 첫 구매 고객 확보 | [원문](https://www.tangent.ai/hello-seen) |
| `PMD-20261001-001` | 비공개 단일 브랜드 커머스 / Promodo | 상품 페이지 GEO — AI 유입 채널 확대 | [원문](https://www.promodo.com/case-studies/how-geo-works-for-ecommerce) |

## 연결할 카테고리

- [1-2 전환율 상승](1-2_conversion.md)
- [2-1 마케팅 운영비 절감](2-1_marketing_cost.md)

## 다음 갱신

신규·보강 자료를 검토해 기준 JSON과 출처 기록을 수정하고, 이 문서의 목록·비교·하위 연구 질문에 반영한다. 과거 seed 표시와 현재 원문 검증 상태를 별도로 유지한다.
