# 1-4 재구매·LTV 확대

[영업·마케팅 위키](../README.md) · [전체 카테고리](README.md)

상태: 카테고리 정의·seed 목록 작성 / 기준일: 2026-10-05 / seed 레코드: 7건

## 범위

구매 후 관계를 유지해 재구매·갱신·장기 고객 가치를 높이는 AI 활용을 다룬다.

포함 영역: 이탈 예측, CRM 개인화, 다음 행동 추천, 로열티, 재구매 캠페인.

예측 LTV를 활용한 신규 획득과 실제 장기 LTV 상승을 구분한다. 문의 처리비는 2-3에서 다룬다.

## 핵심 연구 질문

- AI가 어느 시점의 이탈·재구매 신호를 포착하는가?
- 고객 이해가 후속 접점에 어떻게 연결되는가?
- 예측 점수 개선이 실제 유지율 개선으로 이어지는가?

## 앞으로 작성할 하위 연구 문서

다음은 작성 범위의 정의이며, 개별 심층 문서는 아직 생성하지 않았다. 사례별 문서는 공통 cases 폴더에 한 번만 만들고 이 문서에서 연결한다.

1. **이탈 예측과 유지 활동**
2. **고객 기억·CRM 개인화**
3. **재구매·LTV의 장기 측정**

## 성과를 읽는 기준

재구매율, 갱신율, 이탈률, 코호트 매출, 실현 LTV. 예측 정확도를 고객 유지 성과로 대체하지 않는다.

## 현재 seed 목록

아래 기업명·제목은 제공된 JSON의 목록을 옮긴 것이다. 원문을 이번에 재검증하지 않았으며, 분류 적합성·성과의 정확성이 확정된 목록은 아니다. 기존 ID와 분류를 유지했다. [기준 JSON](../../data/processed/AI_SalesMarketing/cases.json) · [기존 HTML 열람](../../exports/AI_SalesMarketing/ax_cases_atlas.html)

| 기존 ID | 기업 | seed 제목 | 출처 |
| --- | --- | --- | --- |
| `NFX-001` | Netflix | AI 개인화 추천으로 최저 이탈률 | [원문](https://www.prosemedia.com/blog/predicting-customer-churn-before-it-happens-how-ai-driven-insights-help-retain-high-value-clients) |
| `TMO-001` | T-Mobile | AI 이탈 예측 CRM | [원문](https://www.prosemedia.com/blog/predicting-customer-churn-before-it-happens-how-ai-driven-insights-help-retain-high-value-clients) |
| `NKE-001` | 나이키 | AI CRM 개인화 — D2C 재구매 | [원문](https://digitaldefynd.com/IQ/ways-nike-use-ai/) |
| `ADB-001` | Audiobooks.com | AI 구독 이탈 예측 모델 | [원문](https://provectus.com/case-studies/user-churn-prediction-with-ai/) |
| `SFC-20260601-573772` | Salesforce | AI 기반 고객 경험 개선 | [원문](https://www.salesforce.com/blog/design-headless-ai-experiences/) |
| `PDR-20261001-001` | Pandora | 예측 LTV 기반 입찰 — 장기 가치가 높은 고객에 투자 | [원문](https://business.google.com/us/think/measurement/pandora-search-lifetime-value/) |
| `MDC-20261001-001` | Medichecks | 개인화 재활성화 — 12개월 미구매 고객 복귀 | [원문](https://www.bloomreach.com/en/case-studies/medichecks) |

## 연결할 카테고리

- [1-1 신규 고객 획득](1-1_customer_acquisition.md)
- [1-3 객단가·Mix 개선](1-3_order_value_mix.md)
- [2-3 CS·케어 비용 절감](2-3_customer_care_cost.md)

## 다음 갱신

신규·보강 자료를 검토해 기준 JSON과 출처 기록을 수정하고, 이 문서의 목록·비교·하위 연구 질문에 반영한다. 과거 seed 표시와 현재 원문 검증 상태를 별도로 유지한다.
