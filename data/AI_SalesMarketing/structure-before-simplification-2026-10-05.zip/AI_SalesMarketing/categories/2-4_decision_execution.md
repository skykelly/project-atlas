# 2-4 운영 판단력·실행력

[영업·마케팅 위키](../README.md) · [전체 카테고리](README.md)

상태: 카테고리 정의·seed 목록 작성 / 기준일: 2026-10-05 / seed 레코드: 17건

## 범위

데이터를 해석해 판단·조치·결과 확인으로 연결하는 AI 활용을 다룬다.

포함 영역: 매출·수요 예측, 재고·판촉 판단, VOC 분석, 운영 보고, 실행안 추천.

공급망 등 인접 업무는 영업·마케팅 연결 여부를 표시한다. 실행 시간 절감과 판단 품질은 따로 본다.

## 핵심 연구 질문

- 데이터에서 조치까지 어떤 흐름으로 연결되는가?
- 예측·추천·승인·실행 중 AI와 사람이 맡는 부분은 무엇인가?
- 정확도나 분석 범위가 실제 사업 결과를 바꾸는가?

## 앞으로 작성할 하위 연구 문서

다음은 작성 범위의 정의이며, 개별 심층 문서는 아직 생성하지 않았다. 사례별 문서는 공통 cases 폴더에 한 번만 만들고 이 문서에서 연결한다.

1. **예측·운영 판단과 사업 결과**
2. **VOC·리서치 기반 의사결정**
3. **판단→조치→피드백의 업무 흐름**

## 성과를 읽는 기준

예측 오차, 의사결정 시간, 실제 조치율, 재고·품절, 운영 성과. 커버리지·도입 규모를 성과로 대신하지 않는다.

## 현재 seed 목록

아래 기업명·제목은 제공된 JSON의 목록을 옮긴 것이다. 원문을 이번에 재검증하지 않았으며, 분류 적합성·성과의 정확성이 확정된 목록은 아니다. 기존 ID와 분류를 유지했다. [기준 JSON](../../data/processed/AI_SalesMarketing/cases.json) · [기존 HTML 열람](../../exports/AI_SalesMarketing/ax_cases_atlas.html)

| 기존 ID | 기업 | seed 제목 | 출처 |
| --- | --- | --- | --- |
| `WMT-001` | Walmart | AI 수요 예측 & 공급망 최적화 | [원문](https://www.supplychaindive.com/news/4-walmart-supply-chain-ai-uses/760891/) |
| `ZAR-001` | 자라 (Inditex) | AI 실시간 재고·수요 관리 | [원문](https://wjarr.com/sites/default/files/WJARR-2024-2173.pdf) |
| `MCK-001` | McKinsey | GenAI 의사결정 보조 | [원문](https://www.mckinsey.com/capabilities/quantumblack/our-insights/the-state-of-ai) |
| `SAM-001` | 삼성전자 | AI SCM — 글로벌 재고 자동 재배분 | [원문](https://proinsightsportal.com/ai/ai-powered-inventory-forecasting-how-retailers-cut-overstock-costs-by-60-using-demand-prediction-models/) |
| `OPA-20260506-aad487` | Opal | 캠페인 정렬 비용 절감 | [원문](https://www.marketingdive.com/news/inside-opals-attempt-to-reduce-ais-alignment-tax-for-marketers/818388/) |
| `UA-20260521-4cdacf` | Under Armour | 언더아머 SKU 25% 감소 | [원문](https://www.supplychaindive.com/news/under-armour-reaches-25-sku-reduction-goal/820387/) |
| `TGT-20260527-34d776` | Target | 타겟, 재고 회전율 개선 | [원문](https://www.supplychaindive.com/news/target-touts-improved-inventory-turns-in-q1/821027/) |
| `SFC-20260626-ad01d4` | Salesforce | AI 기반 협업 강화 | [원문](https://www.salesforce.com/blog/open-discovery-agentic-enterprise/) |
| `CLR-20260626-b70937` | Claire's | 클레어스 물류센터 개소 | [원문](https://www.supplychaindive.com/news/claires-opens-illinois-distribution-center-to-boost-inventory-flow/823665/) |
| `MJM-20260630-9f713a` | Majors Management | AI로 운영 효율성 강화 | [원문](https://www.supplychaindive.com/news/majors-management-taps-ai-tool-for-pricing-inventory-and-operations/823870/) |
| `SMG-20260710-411366` | Scotts Miracle-Gro | AI 활용 사례 | [원문](https://www.supplychaindive.com/news/scotts-miracle-gro-widens-tech-partnership-for-supply-chain-ai/824764/) |
| `COG-20260717-434ea1` | Cognigy | AI Copilot로 효율성 향상 | [원문](https://www.cognigy.com/blog/ai-copilot-explained) |
| `CAG-20260725-0ad6e1` | Conagra Brands | 공급망 회복력 강화 | [원문](https://www.supplychaindive.com/news/conagra-to-invest-125m-in-supply-chain-resilience/825796/) |
| `WMT-20260730-eb7187` | Walmart | Walmart의 AI 공급망 최적화 | [원문](https://www.supplychaindive.com/news/how-walmart-uses-ai-to-limit-weather-disruptions-in-its-supply-chain/826391/) |
| `CVI-20261001-001` | Conversios | 광고 계정 감사 루프 — 121개 계정 자동 분석 | [원문](https://about.ads.microsoft.com/en/resources/discover/case-studies/conversios-customer-success-story) |
| `PEPD-20261001-001` | PepsiCo | 공급망 디지털 트윈 — 물리 변경 전 시뮬레이션 검증 | [원문](https://www.pepsico.com/newsroom/press-releases/2025/pepsico-announces-industry-first-ai-and-digital-twin-collaboration-with-siemens-and-nvidia) |
| `SSK-20261005-001` | Sai Silks Kalamandir | 리테일 수요·재고·VOC 판단 | [원문](https://timesofindia.indiatimes.com/technology/aiq/how-sai-silks-kalamandir-limited-is-using-ai-to-build-intelligence-across-the-retail-value-chain/articleshow/134565507.cms) |

## 연결할 카테고리

- [1-3 객단가·Mix 개선](1-3_order_value_mix.md)
- [2-1 마케팅 운영비 절감](2-1_marketing_cost.md)
- [2-2 영업 운영비 절감](2-2_sales_cost.md)

## 다음 갱신

신규·보강 자료를 검토해 기준 JSON과 출처 기록을 수정하고, 이 문서의 목록·비교·하위 연구 질문에 반영한다. 과거 seed 표시와 현재 원문 검증 상태를 별도로 유지한다.
