# 2-3 CS·케어 비용 절감

[영업·마케팅 위키](../README.md) · [전체 카테고리](README.md)

상태: 카테고리 정의·seed 목록 작성 / 기준일: 2026-10-05 / seed 레코드: 10건

## 범위

고객 문의·상담·사후 케어의 처리 부담과 비용을 줄이는 AI 활용을 다룬다.

포함 영역: 챗·보이스 에이전트, 상담원 보조, 지식 검색, 분류·이관, 셀프서비스.

유지·재구매 효과는 1-4, 오답·정책 위반 손실은 2-5와 연결한다.

## 핵심 연구 질문

- 해결·처리·응답·셀프서비스 비율의 정의는 무엇인가?
- 어떤 상황에서 사람에게 넘기는가?
- 고객 경험과 해결 품질을 유지하면서 비용을 줄이는가?

## 앞으로 작성할 하위 연구 문서

다음은 작성 범위의 정의이며, 개별 심층 문서는 아직 생성하지 않았다. 사례별 문서는 공통 cases 폴더에 한 번만 만들고 이 문서에서 연결한다.

1. **상담 자동화와 실제 해결**
2. **상담원 보조·지식 관리**
3. **사람 이관과 서비스 품질**

## 성과를 읽는 기준

건당 비용, 처리 시간, 해결률, 재문의율, 고객 만족도. 인력 비용 회피 추정과 실제 비용 감소를 구분한다.

## 현재 seed 목록

아래 기업명·제목은 제공된 JSON의 목록을 옮긴 것이다. 원문을 이번에 재검증하지 않았으며, 분류 적합성·성과의 정확성이 확정된 목록은 아니다. 기존 ID와 분류를 유지했다. [기준 JSON](../../data/processed/AI_SalesMarketing/cases.json) · [기존 HTML 열람](../../exports/AI_SalesMarketing/ax_cases_atlas.html)

| 기존 ID | 기업 | seed 제목 | 출처 |
| --- | --- | --- | --- |
| `KLA-002` | 클라르나 | AI CS 챗봇 — 서비스 자동화 | [원문](https://www.klarna.com/international/press/klarna-ai-assistant-handles-two-thirds-of-customer-service-chats-in-its-first-month/) |
| `VOD-001` | 보다폰 | TOBi AI — 15개국 CS 자동화 | [원문](https://www.ibm.com/case-studies/vodafone-tobi) |
| `BSC-001` | 보쉬 | Cognigy Agent Copilot | [원문](https://www.cognigy.com/ai-agents/examples-ai-agents) |
| `PAN-001` | 파나소닉 CE | Freshworks Freddy AI | [원문](https://diginomica.com/customer-voice-panasonic-consumer-electronics-and-ringcentral-execs-talk-about-their-ai-journeys) |
| `CGY-20260506-b5a316` | Cognigy | AI로 CS 비용 절감 | [원문](https://www.cognigy.com/blog/generative-ai-customer-service) |
| `CGI-20260506-0bd9cc` | CGI | AI로 고객 서비스 혁신 | [원문](https://www.cognigy.com/blog/shaping-the-future-of-ai-service-how-cgi-and-cognigy-deliver-real-world-results-with-agentic-ai) |
| `SFC-20260701-022ac8` | Salesforce | AI로 CS 비용 절감 | [원문](https://www.salesforce.com/blog/agentic-order-servicing/) |
| `ICM-20261001-001` | Intercom | Fin 내부 CS — 81% 이상 해결과 인력 증원 회피 | [원문](https://www.intercom.com/blog/automate-customer-service-while-improving-customer-experience/) |
| `GAM-20261001-001` | Gamma | AI CS 확장 — 문의 75% 해결·월 1.8만 건 처리 | [원문](https://fin.ai/customers/gamma) |
| `DRM-20261005-001` | Dr. Martens | 고객 데이터 통합·CS Agent | [원문](https://www.itpro.com/business/digital-transformation/we-have-an-ambition-to-be-the-worlds-most-desired-premium-footwear-brand-how-dr-martens-is-working-with-salesforce-to-create-agentic-experiences-for-customers) |

## 연결할 카테고리

- [1-4 재구매·LTV 확대](1-4_retention_ltv.md)
- [2-2 영업 운영비 절감](2-2_sales_cost.md)
- [2-5 리스크·품질 비용](2-5_risk_quality.md)

## 다음 갱신

신규·보강 자료를 검토해 기준 JSON과 출처 기록을 수정하고, 이 문서의 목록·비교·하위 연구 질문에 반영한다. 과거 seed 표시와 현재 원문 검증 상태를 별도로 유지한다.
