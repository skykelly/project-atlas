# 1-5 신규 수익모델

[영업·마케팅 위키](../README.md) · [전체 카테고리](README.md)

상태: 카테고리 정의·seed 목록 작성 / 기준일: 2026-10-05 / seed 레코드: 6건

## 범위

AI로 새 상품·서비스·과금 방식·판매 시장을 만드는 사례를 다룬다.

포함 영역: AI 서비스 판매, 구독, 성과·사용량 과금, 신규 채널·시장.

기존 매출의 효율 개선과 새로운 매출원은 구분한다. 절감액을 신규 수익으로 계산하지 않는다.

## 핵심 연구 질문

- 기존과 달리 누구에게 무엇을 판매하는가?
- 과금 기준과 실제 수익의 증거가 있는가?
- 출시·계약·ARR·인식 매출을 구분할 수 있는가?

## 앞으로 작성할 하위 연구 문서

다음은 작성 범위의 정의이며, 개별 심층 문서는 아직 생성하지 않았다. 사례별 문서는 공통 cases 폴더에 한 번만 만들고 이 문서에서 연결한다.

1. **AI 상품·서비스의 사업화**
2. **사용량·성과 기반 과금**
3. **신규 시장·채널과 매출 기여**

## 성과를 읽는 기준

신규 매출, 유료 고객, ARPU, ARR, 이익 기여. 발표·전망·ARR을 실제 분기 매출과 구분한다.

## 현재 seed 목록

아래 기업명·제목은 제공된 JSON의 목록을 옮긴 것이다. 원문을 이번에 재검증하지 않았으며, 분류 적합성·성과의 정확성이 확정된 목록은 아니다. 기존 ID와 분류를 유지했다. [기준 JSON](../../data/processed/AI_SalesMarketing/cases.json) · [기존 HTML 열람](../../exports/AI_SalesMarketing/ax_cases_atlas.html)

| 기존 ID | 기업 | seed 제목 | 출처 |
| --- | --- | --- | --- |
| `BOA-001` | 뱅크오브아메리카 | Erica AI — 금융 서비스 신수익 | [원문](https://newsroom.bankofamerica.com/content/newsroom/press-releases/2025/08/a-decade-of-ai-innovation--bofa-s-virtual-assistant-erica-surpas.html) |
| `LMN-001` | 루멘 테크놀로지스 | MS Copilot — B2B 영업 신시장 | [원문](https://news.microsoft.com/source/features/digital-transformation/the-only-way-how-copilot-is-helping-propel-an-evolution-at-lumen-technologies/) |
| `SFO-001` | Salesforce | Agentforce — AI 영업 에이전트 | [원문](https://www.salesforce.com/salesforce-on-salesforce-stories/) |
| `GE-001` | GE (산업) | AI 예측 정비 서비스 SaaS화 | [원문](https://www.mckinsey.com/capabilities/operations/our-insights/capturing-the-true-value-of-industry-4-0) |
| `SFM-20261001-001` | Salesforce | Agentforce 상용 판매 — AI 실행 역량의 수익화 | [원문](https://www.salesforce.com/news/press-releases/2026/08/26/fy27-q2-earnings/) |
| `FINM-20261001-001` | Fin / Intercom | 해결 건수에서 Outcomes로 — AI 업무 성과 과금 | [원문](https://fin.ai/updates/fin-pricing-metric) |

## 연결할 카테고리

- [1-1 신규 고객 획득](1-1_customer_acquisition.md)
- [1-3 객단가·Mix 개선](1-3_order_value_mix.md)
- [2-2 영업 운영비 절감](2-2_sales_cost.md)

## 다음 갱신

신규·보강 자료를 검토해 기준 JSON과 출처 기록을 수정하고, 이 문서의 목록·비교·하위 연구 질문에 반영한다. 과거 seed 표시와 현재 원문 검증 상태를 별도로 유지한다.
