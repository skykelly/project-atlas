# 1-3 객단가·Mix 개선

[영업·마케팅 위키](../README.md) · [전체 카테고리](README.md)

상태: 카테고리 정의·seed 목록 작성 / 기준일: 2026-10-05 / seed 레코드: 9건

## 범위

주문당 구매 금액·제품 구성·마진을 개선하는 AI 활용을 다룬다.

포함 영역: 업셀·크로스셀, 번들·루틴 추천, 가격·판촉 최적화, 고부가 제품 제안.

전환 증가와 객단가 증가는 분리한다. 기존 데이터의 광고 수익률·벤치마크 사례는 분류 적합성을 검토한다.

## 핵심 연구 질문

- 고객에게 어떤 추가 가치나 조합을 제안하는가?
- 객단가 상승이 할인·반품을 반영한 마진 개선인가?
- 추천 이용자와 비이용자의 차이를 AI 효과로 단정할 수 있는가?

## 앞으로 작성할 하위 연구 문서

다음은 작성 범위의 정의이며, 개별 심층 문서는 아직 생성하지 않았다. 사례별 문서는 공통 cases 폴더에 한 번만 만들고 이 문서에서 연결한다.

1. **업셀·크로스셀과 제품 조합**
2. **AI 가격·판촉과 마진**
3. **객단가·Mix 성과의 측정 조건**

## 성과를 읽는 기준

AOV, 주문당 품목 수, 고부가 제품 비중, 매출총이익. ROAS와 객단가는 별개 지표다.

## 현재 seed 목록

아래 기업명·제목은 제공된 JSON의 목록을 옮긴 것이다. 원문을 이번에 재검증하지 않았으며, 분류 적합성·성과의 정확성이 확정된 목록은 아니다. 기존 ID와 분류를 유지했다. [기준 JSON](../../data/processed/AI_SalesMarketing/cases.json) · [기존 HTML 열람](../../exports/AI_SalesMarketing/ax_cases_atlas.html)

| 기존 ID | 기업 | seed 제목 | 출처 |
| --- | --- | --- | --- |
| `RYN-001` | Ryanair | AI 부가 서비스 업셀링 | [원문](https://superagi.com/case-study-how-companies-are-using-ai-to-identify-upsell-and-cross-sell-opportunities-in-2025/) |
| `PNG-001` | P&G | AI 알고리즘 미디어 바잉 | [원문](https://www.marketingweek.com/pg-ai-best-possible-value-ad/) |
| `BCG-001` | BCG | AI 개인화 번들 — 소비재 벤치마크 | [원문](https://www.bcg.com/publications/2025/are-you-generating-value-from-ai-the-widening-gap) |
| `IKE-001` | 이케아 | AI 동적 프라이싱 | [원문](https://www.articsledge.com/post/machine-learning-retail-case-studies) |
| `DTC-20260627-872fd6` | Duluth Trading Co. | 재고 건강 개선 사례 | [원문](https://www.supplychaindive.com/news/duluth-trading-boosts-inventory-health-with-sku-cuts-enterprise-planning/823796/) |
| `OLP-20261001-001` | Olaplex | AI 루틴 추천 — 매장 평균 대비 객단가 48% 상회 | [원문](https://www.tangent.ai/olaplex-higher-aov) |
| `KIW-20261001-001` | Kiwabi | AI 진단 — 단품에서 제품 루틴으로 구매 확대 | [원문](https://www.tangent.ai/kiwabi-case-study) |
| `PEPR-20261001-001` | PepsiCo | PromoAI·PricingAI — 가격·판촉 포트폴리오 최적화 | [원문](https://pubsonline.informs.org/doi/abs/10.1287/inte.2025.0302) |
| `MCDP-20261005-001` | McDonald's | 매장별 AI 가격 추천 | [원문](https://www.reuters.com/business/inside-mcdonalds-push-have-ai-price-your-big-mac-2026-09-29/) |

## 연결할 카테고리

- [1-2 전환율 상승](1-2_conversion.md)
- [1-4 재구매·LTV 확대](1-4_retention_ltv.md)
- [2-4 운영 판단력·실행력](2-4_decision_execution.md)

## 다음 갱신

신규·보강 자료를 검토해 기준 JSON과 출처 기록을 수정하고, 이 문서의 목록·비교·하위 연구 질문에 반영한다. 과거 seed 표시와 현재 원문 검증 상태를 별도로 유지한다.
