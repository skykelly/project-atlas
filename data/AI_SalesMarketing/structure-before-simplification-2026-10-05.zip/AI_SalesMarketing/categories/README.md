# 10개 성과 카테고리

[위키 홈](../README.md)

기존 category 코드와 이름을 유지한다. 아래 수는 2026-10-05 seed 레코드 수이며 독립 프로젝트 수나 검증 완료 건수가 아니다.

| 코드 | 카테고리 문서 | seed 레코드 |
| --- | --- | ---: |
| 1-1 | [신규 고객 획득](1-1_customer_acquisition.md) | 34 |
| 1-2 | [전환율 상승](1-2_conversion.md) | 12 |
| 1-3 | [객단가·Mix 개선](1-3_order_value_mix.md) | 9 |
| 1-4 | [재구매·LTV 확대](1-4_retention_ltv.md) | 7 |
| 1-5 | [신규 수익모델](1-5_new_revenue_models.md) | 6 |
| 2-1 | [마케팅 운영비 절감](2-1_marketing_cost.md) | 9 |
| 2-2 | [영업 운영비 절감](2-2_sales_cost.md) | 6 |
| 2-3 | [CS·케어 비용 절감](2-3_customer_care_cost.md) | 10 |
| 2-4 | [운영 판단력·실행력](2-4_decision_execution.md) | 17 |
| 2-5 | [리스크·품질 비용](2-5_risk_quality.md) | 7 |

같은 도입이 여러 성과에 연결되어도 사례 본문은 cases 폴더에서 한 번만 관리한다. topic과 ai_mode는 보조 분류다.

[분류 설정](../../config/AI_SalesMarketing/categories.json)에는 각 문서의 범위·질문·향후 하위 연구 문서 정의가 있다. 정의를 변경하면 해당 설정과 문서를 함께 갱신한다.
