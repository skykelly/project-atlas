# 2-2 영업 운영비 절감

[영업·마케팅 위키](../README.md) · [전체 카테고리](README.md)

상태: 카테고리 정의·seed 목록 작성 / 기준일: 2026-10-05 / seed 레코드: 6건

## 범위

영업 준비·실행·기록 과정의 반복 업무와 운영 부담을 줄이는 AI 활용을 다룬다.

포함 영역: 계정 조사, 미팅 준비·요약, 제안·견적, CRM 입력, 후속 연락.

수주·매출 효과는 1-2, 미접촉 고객 확보는 1-1과 연결한다.

## 핵심 연구 질문

- 영업사원의 어떤 업무 사이클이 바뀌는가?
- CRM·제품·가격·정책 정보가 어떻게 연결되는가?
- 시간 절감이 고객 접촉이나 영업 활동 증가로 이어지는가?

## 앞으로 작성할 하위 연구 문서

다음은 작성 범위의 정의이며, 개별 심층 문서는 아직 생성하지 않았다. 사례별 문서는 공통 cases 폴더에 한 번만 만들고 이 문서에서 연결한다.

1. **고객 조사·미팅 준비**
2. **제안서·견적·CRM 기록**
3. **영업 에이전트와 사람의 역할**

## 성과를 읽는 기준

조사·제안 시간, 판매 활동 시간 비중, 기록 완결성, 인당 처리량, 총 운영비. 개인 경험을 팀 전체 성과로 일반화하지 않는다.

## 현재 seed 목록

아래 기업명·제목은 제공된 JSON의 목록을 옮긴 것이다. 원문을 이번에 재검증하지 않았으며, 분류 적합성·성과의 정확성이 확정된 목록은 아니다. 기존 ID와 분류를 유지했다. [기준 JSON](../../data/processed/AI_SalesMarketing/cases.json) · [기존 HTML 열람](../../exports/AI_SalesMarketing/ax_cases_atlas.html)

| 기존 ID | 기업 | seed 제목 | 출처 |
| --- | --- | --- | --- |
| `LMN-002` | 루멘 테크놀로지스 | MS Copilot — 영업 생산성 혁신 | [원문](https://news.microsoft.com/source/features/digital-transformation/the-only-way-how-copilot-is-helping-propel-an-evolution-at-lumen-technologies/) |
| `BAI-001` | Bain & Company | AI로 영업 활동 시간 2배 | [원문](https://www.bain.com/insights/ai-transforming-productivity-sales-remains-new-frontier-technology-report-2025/) |
| `CRC-001` | CRC Industries | Copilot Studio 견적 자동화 | [원문](https://c5insight.com/3-microsoft-365-copilot-case-studies/) |
| `FOR-001` | Forrester | MS 365 Copilot TEI 연구 | [원문](https://www.gestisoft.com/en/blog/copilot-roi) |
| `ANT-20261001-001` | Anthropic | 영업 주간 루프 — 브리핑·예측·4천 계정 조사 자동화 | [원문](https://claude.com/blog/how-an-anthropic-sales-leader-uses-claude-cowork-to-run-a-4-000-account-book) |
| `VMD-20261001-001` | 비공개 의료기기 유통사 / Velosio | ERP 조회 Agent — 영업·CS의 데이터 검색 부담 절감 | [원문](https://www.velosio.com/case-studies/medical-device-distributor/) |

## 연결할 카테고리

- [1-1 신규 고객 획득](1-1_customer_acquisition.md)
- [1-2 전환율 상승](1-2_conversion.md)
- [2-4 운영 판단력·실행력](2-4_decision_execution.md)

## 다음 갱신

신규·보강 자료를 검토해 기준 JSON과 출처 기록을 수정하고, 이 문서의 목록·비교·하위 연구 질문에 반영한다. 과거 seed 표시와 현재 원문 검증 상태를 별도로 유지한다.
