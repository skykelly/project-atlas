# 2-1 마케팅 운영비 절감

[영업·마케팅 위키](../README.md) · [전체 카테고리](README.md)

상태: 카테고리 정의·seed 목록 작성 / 기준일: 2026-10-05 / seed 레코드: 9건

## 범위

마케팅 기획·제작·집행·보고 과정의 시간과 원가를 줄이는 AI 활용을 다룬다.

포함 영역: 콘텐츠 생성·현지화, 디자인·영상, 캠페인 운영, 인사이트·보고 자동화.

고객 획득 성과는 1-1, 전략 판단은 2-4와 연결한다. 처리량 증가는 실제 지출 감소와 구분한다.

## 핵심 연구 질문

- 자동화되는 작업과 사람의 검수 범위는 무엇인가?
- 재작업·검수·도구 비용을 포함해 절감되는가?
- 절약 시간을 어떤 업무에 재투입하는가?

## 앞으로 작성할 하위 연구 문서

다음은 작성 범위의 정의이며, 개별 심층 문서는 아직 생성하지 않았다. 사례별 문서는 공통 cases 폴더에 한 번만 만들고 이 문서에서 연결한다.

1. **콘텐츠 제작·현지화**
2. **캠페인 운영·분석 자동화**
3. **마케팅 생산성의 비용 환산**

## 성과를 읽는 기준

제작 단가, 리드타임, 인당 산출물, 외주비, 재작업률. 예상 절감과 실현 비용을 구분한다.

## 현재 seed 목록

아래 기업명·제목은 제공된 JSON의 목록을 옮긴 것이다. 원문을 이번에 재검증하지 않았으며, 분류 적합성·성과의 정확성이 확정된 목록은 아니다. 기존 ID와 분류를 유지했다. [기준 JSON](../../data/processed/AI_SalesMarketing/cases.json) · [기존 HTML 열람](../../exports/AI_SalesMarketing/ax_cases_atlas.html)

| 기존 ID | 기업 | seed 제목 | 출처 |
| --- | --- | --- | --- |
| `KLA-001` | 클라르나 | GenAI 인하우스 콘텐츠 팩토리 | [원문](https://www.klarna.com/international/press/ai-helps-klarna-cut-marketing-agency-spend-by-25-and-run-more-campaigns/) |
| `UNI-002` | 유니레버 | NVIDIA Omniverse 디지털 트윈 | [원문](https://technologymagazine.com/articles/how-unilever-is-reinventing-product-marketing-with-ai) |
| `NES-001` | 네슬레 | NesGPT — 마케팅 인사이트 AI | [원문](https://www.nestle.com/media/news/brands-ai-digital-twins-content-service) |
| `PNG-002` | P&G | 에이전시 통합 + AI 인하우스 전환 | [원문](https://www.marketingweek.com/pg-ai-best-possible-value-ad/) |
| `P&G-20260509-0df3f8` | Procter & Gamble | P&G 공급망 혁신 | [원문](https://www.supplychaindive.com/news/pg-shifts-supply-chain-30-other-platforms-into-large-scale-rollout/819256/) |
| `STG-20261001-001` | Stagwell / Assembly | MCP 연결 광고 감사 Agent — 수시간 작업을 수분으로 | [원문](https://about.ads.microsoft.com/en/resources/discover/case-studies/stagwell-customer-success-story) |
| `MDZ-20261001-001` | Mondelez International | AIDA 콘텐츠 생산 — 브랜드 지식·AI 검수·사람 승인 | [원문](https://www.beet.tv/2026/08/gen-ai-speeds-content-production-for-our-brands-mondelez-internationals-michael-lampert.html) |
| `PUT-20261005-001` | PuttEZ | 웹·콘텐츠 운영 Agent | [원문](https://www.businessinsider.com/instinct-ai-agent-helped-entrepreneur-run-new-business-puttez-2026-10) |
| `GNP-20261005-001` | GreenPortfolio | 광고 진단·카피 AI 보조 | [원문](https://www.businessinsider.com/small-business-marketing-benefits-downsides-ai-tools-2026-10) |

## 연결할 카테고리

- [1-1 신규 고객 획득](1-1_customer_acquisition.md)
- [2-4 운영 판단력·실행력](2-4_decision_execution.md)
- [2-5 리스크·품질 비용](2-5_risk_quality.md)

## 다음 갱신

신규·보강 자료를 검토해 기준 JSON과 출처 기록을 수정하고, 이 문서의 목록·비교·하위 연구 질문에 반영한다. 과거 seed 표시와 현재 원문 검증 상태를 별도로 유지한다.
