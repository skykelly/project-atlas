# 2-5 리스크·품질 비용

[영업·마케팅 위키](../README.md) · [전체 카테고리](README.md)

상태: 카테고리 정의·seed 목록 작성 / 기준일: 2026-10-05 / seed 레코드: 7건

## 범위

잘못된 판단·거래·응대·콘텐츠로 생기는 손실과 품질 비용을 줄이는 AI 활용을 다룬다.

포함 영역: 사기·오탐 탐지, 브랜드·콘텐츠 검수, 응대 품질, 정책 준수, 배포 전 평가.

보안 전반보다 영업·마케팅·거래·고객 경험의 손실에 초점을 둔다. 이탈 예측은 1-4와 연결한다.

## 핵심 연구 질문

- 어떤 손실이나 품질 실패를 줄이는가?
- 오탐·미탐·거절로 생기는 기회비용은 무엇인가?
- 검증 지표가 실제 사고·재작업·손실 감소로 이어지는가?

## 앞으로 작성할 하위 연구 문서

다음은 작성 범위의 정의이며, 개별 심층 문서는 아직 생성하지 않았다. 사례별 문서는 공통 cases 폴더에 한 번만 만들고 이 문서에서 연결한다.

1. **거래 위험과 오탐 거절**
2. **콘텐츠·브랜드·응대 품질**
3. **AI 배포 전 평가와 운영 감시**

## 성과를 읽는 기준

손실액, 부정 거래율, 승인·거절률, 오탐·미탐, 재작업·불만. 탐지 정확도와 금액 효과를 구분한다.

## 현재 seed 목록

아래 기업명·제목은 제공된 JSON의 목록을 옮긴 것이다. 원문을 이번에 재검증하지 않았으며, 분류 적합성·성과의 정확성이 확정된 목록은 아니다. 기존 ID와 분류를 유지했다. [기준 JSON](../../data/processed/AI_SalesMarketing/cases.json) · [기존 HTML 열람](../../exports/AI_SalesMarketing/ax_cases_atlas.html)

| 기존 ID | 기업 | seed 제목 | 출처 |
| --- | --- | --- | --- |
| `UNI-003` | 유니레버 | AI 소비자 인사이트 — VOC 조기 탐지 | [원문](https://infotechlead.com/cio/unilever-drives-digital-ai-and-e-commerce-growth-with-2x-faster-marketing-and-e800-mn-cost-savings-94832) |
| `ZND-001` | Zendesk | AI Spotlight — 위험 케이스 자동 감지 | [원문](https://www.prosemedia.com/blog/predicting-customer-churn-before-it-happens-how-ai-driven-insights-help-retain-high-value-clients) |
| `ADB-002` | Audiobooks.com | AI 구독 리스크 조기 대응 | [원문](https://provectus.com/case-studies/user-churn-prediction-with-ai/) |
| `PNG-003` | P&G | AI 브랜드 리스크 모니터링 | [원문](https://www.marketingweek.com/pg-ai-best-possible-value-ad/) |
| `KOG-20261001-001` | Kogan.com | AI 사기·정책 악용 탐지 — 연 150만 달러 절감 식별 | [원문](https://ir.riskified.com/news-releases/news-release-details/kogan-increases-approval-rates-and-improves-customer-experience) |
| `SKC-20261001-001` | Skullcandy | ML 위험 판단 — 오탐 거절과 CS 부담 축소 | [원문](https://www.riskified.com/press/skullcandy-amplifies-ecommerce-growth-and-approval-rates-with-riskified/) |
| `NUQ-20261005-001` | Nubank | CS Agent 배포 전 시뮬레이션 | [원문](https://arxiv.org/abs/2609.30137) |

## 연결할 카테고리

- [1-4 재구매·LTV 확대](1-4_retention_ltv.md)
- [2-1 마케팅 운영비 절감](2-1_marketing_cost.md)
- [2-3 CS·케어 비용 절감](2-3_customer_care_cost.md)

## 다음 갱신

신규·보강 자료를 검토해 기준 JSON과 출처 기록을 수정하고, 이 문서의 목록·비교·하위 연구 질문에 반영한다. 과거 seed 표시와 현재 원문 검증 상태를 별도로 유지한다.
