# 1-2 전환율 상승

[영업·마케팅 위키](../README.md) · [전체 카테고리](README.md)

상태: 카테고리 정의·seed 목록 작성 / 기준일: 2026-10-05 / seed 레코드: 12건

## 범위

관심·문의·탐색 단계의 고객을 구매나 수주로 전환하는 AI 활용을 다룬다.

포함 영역: 검색·추천, 구매 상담, 가상 체험, 영업 코파일럿, 리드 전환.

신규 유입 자체는 1-1, 구매 금액·제품 구성은 1-3, 영업 시간은 2-2에서 비교한다.

## 핵심 연구 질문

- AI 개입이 고객의 어떤 판단을 돕는가?
- 전환율의 분모와 비교 집단은 무엇인가?
- 사용자 선택 편향을 통제한 실험이 있는가?

## 앞으로 작성할 하위 연구 문서

다음은 작성 범위의 정의이며, 개별 심층 문서는 아직 생성하지 않았다. 사례별 문서는 공통 cases 폴더에 한 번만 만들고 이 문서에서 연결한다.

1. **상품 탐색·추천과 구매 전환**
2. **대화형 상담과 구매 결정**
3. **B2B 영업 지원과 수주 전환**

## 성과를 읽는 기준

구매 전환율, 문의→기회→수주율, 이탈률, 수주 기간. 상대 변화와 %p를 구분한다.

## 현재 seed 목록

아래 기업명·제목은 제공된 JSON의 목록을 옮긴 것이다. 원문을 이번에 재검증하지 않았으며, 분류 적합성·성과의 정확성이 확정된 목록은 아니다. 기존 ID와 분류를 유지했다. [기준 JSON](../../data/processed/AI_SalesMarketing/cases.json) · [기존 HTML 열람](../../exports/AI_SalesMarketing/ax_cases_atlas.html)

| 기존 ID | 기업 | seed 제목 | 출처 |
| --- | --- | --- | --- |
| `WAY-001` | Wayfair | AI 고객 여정 개인화 | [원문](https://ecomposer.io/blogs/ecommerce/ai-personalization-ecommerce) |
| `MSF-001` | Microsoft | Copilot for Sales — 영업 코파일럿 | [원문](https://blogs.microsoft.com/blog/2024/10/21/new-autonomous-agents-scale-your-team-like-never-before/) |
| `SIE-001` | 지멘스 | Salesforce Agentforce — 인바운드 자동화 | [원문](https://www.salesforce.com/customer-stories/siemens/) |
| `AMZ-001` | Amazon | AI 추천 엔진 — 크로스셀 | [원문](https://www.netguru.com/blog/machine-learning-sales-cross-sell-upsell-campaigns) |
| `SFC-20260603-39bdb4` | Salesforce | AI 팀원으로 영업 효율화 | [원문](https://www.salesforce.com/blog/agentforce-coworker-salesforce-ai-teammate/) |
| `SFC-20260724-6d4d20` | Salesforce | AI 챗봇으로 고객 응대 개선 | [원문](https://www.salesforce.com/blog/small-business/best-ai-chatbots-for-small-business-service/) |
| `SFC-20260724-f02bd8` | Salesforce | 대화형 AI로 전환율 상승 | [원문](https://www.salesforce.com/blog/salesforce-2026-gartner-magic-quadrant-conversational-ai-platforms/) |
| `LOW-20261001-001` | Lowe's | Mylow — AI 상담 이용자 구매 전환율 3배 | [원문](https://corporate.lowes.com/sites/lowes-corp/files/low-usq-transcript-2026-08-19.pdf) |
| `IDM-20261001-001` | IndiaMART | VANI 음성 Agent — 리드 전환 개선 | [원문](https://www.squadstack.ai/en/case-study/success-story-with-indiamart) |
| `LWB-20261001-001` | Lawless Beauty | AI 파운데이션 매칭 — 전환율 36% | [원문](https://www.tangent.ai/lawless-beauty-case-study) |
| `ULT-20261001-001` | Ulta Beauty | AI 추천 유입 — 전환과 구매 의향 2배 | [원문](https://www.reuters.com/business/retail-consumer/retailers-tap-ai-shopping-traffic-fight-keep-customer-data-2026-08-07/) |
| `TGS-20261005-001` | Target | 하이브리드 상품 검색 | [원문](https://arxiv.org/abs/2609.31498) |

## 연결할 카테고리

- [1-1 신규 고객 획득](1-1_customer_acquisition.md)
- [1-3 객단가·Mix 개선](1-3_order_value_mix.md)
- [2-2 영업 운영비 절감](2-2_sales_cost.md)

## 다음 갱신

신규·보강 자료를 검토해 기준 JSON과 출처 기록을 수정하고, 이 문서의 목록·비교·하위 연구 질문에 반영한다. 과거 seed 표시와 현재 원문 검증 상태를 별도로 유지한다.
