# 영업·마케팅 AI 활용 사례 위키

[Atlas 전체 안내](../README.md) · [실행 계획](../PLAN.md)

AI가 고객 획득·구매·관계·수익과 마케팅·영업·케어·운영·품질을 어떻게 바꾸는지 축적한다. 기존 117개 레코드·10개 성과 카테고리를 출발점으로 한다.

## 읽는 순서

1. [10개 카테고리](categories/README.md)에서 관심 있는 성과 영역을 선택한다.
2. 카테고리 문서에서 범위·연구 질문·seed 사례 목록을 확인한다.
3. 향후 [사례 문서](cases/README.md)와 [출처 기록](sources/README.md)으로 근거를 추적한다.
4. [종합·적용 시사점](insights/README.md)과 [정기 브리프](briefs/README.md)에서 변화를 읽는다.

## 현재 상태

10개 카테고리 문서의 정의와 117개 seed 목록 연결을 완료했다. 117개의 개별 사례 문서와 출처 검증 기록은 아직 생성하지 않았다. seed 수치·분류를 이번 작업에서 원문 대조한 것으로 해석하지 않는다.

문서 폴더에는 Markdown 지식을 저장한다. 데이터는 [data](../data/README.md), 수집·정리 코드는 [src](../src/README.md), 조사 운영은 [research](../research/README.md)에 둔다. 기존 열람 자료는 [HTML](../exports/AI_SalesMarketing/ax_cases_atlas.html)에서 볼 수 있다.

## 문서 간 관계

카테고리 → 사례 → 출처를 연결하고, 종합 문서는 여러 사례를 비교한다. 같은 사례를 여러 주제에 복제하지 않는다. LG 적용 아이디어는 연구자의 가설로 명시하고 LG의 실제 도입과 구분한다.
