# 사례별 근거 연결

[출처 안내](../README.md)

기존 사례 ID에 대응하는 문서로 legacy_verified, source_review_status, checked_at, source_ids, 주장별 근거·제한을 기록한다. 아직 개별 사례의 원문을 재검증한 기록은 없다.
