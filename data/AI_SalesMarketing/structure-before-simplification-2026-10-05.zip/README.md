# Atlas — AI 리서치 위키

여러 AI 주제를 로컬 문서로 축적하고, 반복 조사로 사례·출처·종합 판단을 갱신하는 프로젝트다.

## 주제별 입구

| 주제 | 문서 폴더 | 현재 상태 |
| --- | --- | --- |
| 1. 영업·마케팅 AI 활용 사례 | [AI_SalesMarketing](AI_SalesMarketing/README.md) | 10개 카테고리 정의·117개 seed 목록 연결 |
| 2. AI 업계 전반 동향 | [AI_IndustryTrend](AI_IndustryTrend/README.md) | 후속 조사용 공간 |
| 3. GEO & Agentic Commerce | [AI_GEO_AIcommerce](AI_GEO_AIcommerce/README.md) | 후속 조사용 공간 |
| 4. LG그룹 AI 활용 사례 | [AI_LGgroup](AI_LGgroup/README.md) | 후속 조사용 공간 |

## 전체 폴더 구조

```text
atlas/
├── README.md                         # 전체 입구와 폴더 규칙
├── PLAN.md                           # 실행 계획
├── AGENTS.md                         # LLM의 문서·데이터 편집 규칙
├── AI_SalesMarketing/                # 주제 1의 문서
│   ├── README.md
│   ├── categories/                   # 10개 카테고리 문서
│   │   ├── 1-1_customer_acquisition.md
│   │   ├── 1-2_conversion.md
│   │   ├── 1-3_order_value_mix.md
│   │   ├── 1-4_retention_ltv.md
│   │   ├── 1-5_new_revenue_models.md
│   │   ├── 2-1_marketing_cost.md
│   │   ├── 2-2_sales_cost.md
│   │   ├── 2-3_customer_care_cost.md
│   │   ├── 2-4_decision_execution.md
│   │   └── 2-5_risk_quality.md
│   ├── cases/                        # 개별 사례 문서, 아직 미이관
│   ├── sources/                      # 출처·주장 근거, 아직 미이관
│   │   └── case-evidence/            # 사례 ID별 검증 상태
│   ├── insights/                     # 업무별 종합·적용 시사점
│   └── briefs/                       # 주간·월간 읽기용 문서
├── AI_IndustryTrend/                 # 주제 2, 준비 공간
├── AI_GEO_AIcommerce/                # 주제 3, 준비 공간
├── AI_LGgroup/                       # 주제 4, 준비 공간
├── src/                              # 공통 수집·정리 코드 위치
│   ├── crawlers/
│   ├── processors/
│   ├── wiki/
│   ├── exporters/
│   └── validators/
├── config/                           # 주제·경로·분류·검색 설정
│   ├── topics.json
│   └── AI_SalesMarketing/categories.json
├── data/
│   ├── seed/AI_SalesMarketing/2026-10-05/  # 세 원본과 체크섬
│   ├── raw/                          # 향후 수집 원시 자료
│   └── processed/AI_SalesMarketing/cases.json
├── research/AI_SalesMarketing/       # 점검·조사 대기·실행 기록
├── templates/                        # 사례·출처·종합 양식
└── exports/AI_SalesMarketing/        # HTML 등 열람 산출물
```

## 폴더별 책임

- 네 AI 주제 폴더: 사람이 읽고 LLM이 참조할 위키 문서. 코드나 크롤링 원시 파일을 넣지 않는다.
- [src](src/README.md): 공통 수집·추출·정리·위키 생성·출력·검사 코드. 현재는 디렉터리와 역할 설명만 있다.
- [config](config/README.md): 주제별 경로·카테고리 정의. 미래 검색식도 여기에 둔다.
- [data](data/README.md): 원본 seed, 새 수집 결과, 편집 기준 JSON.
- [research](research/README.md): 선정·보류·재검증 목록과 실행 기록.
- [templates](templates/README.md): 공통 문서 작성 양식.
- [exports](exports/README.md): HTML 등 열람용 출력.

사례의 구조화된 내용은 data/processed, 검증 근거는 주제별 sources, 종합 해석은 주제별 insights에서 관리한다. 사례 Markdown·HTML은 같은 기준 입력을 반영하며 직접 고친 산출물을 별도 진실로 운영하지 않는다.

## 기존 세 파일의 위치

루트에 있던 세 파일을 [원본 보존 폴더](data/seed/AI_SalesMarketing/2026-10-05/README.md)로 이동했다. 내용은 바꾸지 않았고 체크섬을 기록했다.

- 편집 기준: [cases.json](data/processed/AI_SalesMarketing/cases.json)
- 열람 화면: [ax_cases_atlas.html](exports/AI_SalesMarketing/ax_cases_atlas.html)
- 원본 조사 이력: [cases_update_report.md](data/seed/AI_SalesMarketing/2026-10-05/cases_update_report.md)
- 점검 결과: [seed-assessment.md](research/AI_SalesMarketing/seed-assessment.md)

## 이번에 완료한 범위

주제별 폴더와 공통 작업 폴더를 재구성하고, 10개 카테고리마다 범위·질문·향후 하위 연구 문서·지표 해석 기준·seed 목록을 작성했다. 117개 ID는 각각 원래 카테고리 문서의 목록에서 찾을 수 있다.

개별 사례 117건의 Markdown 전환, 출처 기록 생성, 원문 재검증, 크롤러 구현, 예약 변경은 후속 작업이다. 기존 verified 값을 이번 작업의 사실 검증으로 해석하지 않는다.

[실행 계획](PLAN.md) · [다음 조사 목록](research/AI_SalesMarketing/backlog.md)
