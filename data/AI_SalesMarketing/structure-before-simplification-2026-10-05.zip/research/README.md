# 조사 운영 기록

[영업·마케팅 seed 점검](AI_SalesMarketing/seed-assessment.md) · [다음 조사 목록](AI_SalesMarketing/backlog.md)

주제별 선정 기준·검토 대기·실행 결과·실패와 재개 기록을 저장한다. 독자가 읽는 사례·출처·종합 문서는 각 주제 폴더, 원본 입력은 data/seed, 코드는 src에서 관리한다.

실행 이력은 각 주제의 runs에 실행 ID별로 남긴다. 과거 대화에 자동화 활성화 기록이 있으나 현재 예약 상태와 로컬 출력 연결은 별도 확인이 필요하다.
